class Csv
 # csvファイルとDateを扱うためのライブラリを使う
  require 'csv'
  require "date"
  Week = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"]
  # 日～土曜の曜日を出力するために配列で用意
  # 定数をメソッド内で作ろうとしてエラーが出たので、ここに記述


  def read
    @data = CSV.open('timesheet201804.csv')
     # 課題作成中に入手できたCSVファイルを指定している
  end
  
  def main
    read #CSVを開くメソッドを呼び出し
    
    @data.readline # 1行目は使用しないのでreadlineで飛ばす
    worktime = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
     # 日月火水木金土の順番で、作業時間の合計を入れる配列
    date_temp = []
     # いつからいつまでと期間を表示するため、日付を格納する配列

    @data.each do |x| # CSVの2行目以降を1行ずつxに代入、xの中身は配列
      date = Date.parse x[0] # xの0番＝日付をdate型に変え、変数dateに入れる
      date_temp << date # 変数dateを日付だけ格納する配列に入れる
      d = date.wday # 変数dateが何曜日か判断し、値を変数に入れる
      worktime[d] += x[3].to_f 
       # .wdayで出した値とworktime配列の要素番号が対応するので、
       # CSVの労働時間を格納先へ配列へ足し合わせる
       # 現時点では休憩時間を引くことはできないが、ifを使えば可能に思える
    end

    puts "------------------------------------"
    puts ("#{date_temp.last} - #{date_temp.first} 曜日別作業時間")
     # 日付の出力は、予め用意した日付だけの配列から出力
    
    7.times do |i|
      puts ("#{Week[i]} #{worktime[i]}")
       # 1週間は7日なので7回繰り返し。i=0~6でそれぞれが
       # 出力に必要なwork(曜日)とworktime(作業時間)の要素番号に一致する
    end
    
    puts "------------------------------------"

  end
end

worktime = Csv.new
worktime.main